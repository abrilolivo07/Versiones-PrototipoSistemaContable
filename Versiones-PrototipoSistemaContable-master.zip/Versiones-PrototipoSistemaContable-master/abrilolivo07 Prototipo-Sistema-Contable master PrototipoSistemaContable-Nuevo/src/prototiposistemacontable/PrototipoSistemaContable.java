
package prototiposistemacontable;

public class PrototipoSistemaContable {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
